
import os


if os.name == "nt":
    os.system("@cls & @title Overload DDOS Tool by: Anonymous sudan & @color e")
else:
    os.system("clear")
